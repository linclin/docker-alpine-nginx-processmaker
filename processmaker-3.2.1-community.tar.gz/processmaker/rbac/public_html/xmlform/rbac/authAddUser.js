var form_cGNXUnoxwrBVcWFUWXRaWFJ5cWllNUbCsGxvTTg___;
var i;
function loadForm_cGNXUnoxwrBVcWFUWXRaWFJ5cWllNUbCsGxvTTg___(ajaxServer)
{
if (typeof(G_Form)==='undefined') return alert('form.js was not loaded');
  form_cGNXUnoxwrBVcWFUWXRaWFJ5cWllNUbCsGxvTTg___=new G_Form(document.getElementById('cGNXUnoxwrBVcWFUWXRaWFJ5cWllNUbCsGxvTTg___'),'cGNXUnoxwrBVcWFUWXRaWFJ5cWllNUbCsGxvTTg___');
  var myForm=form_cGNXUnoxwrBVcWFUWXRaWFJ5cWllNUbCsGxvTTg___;
  myForm.ajaxServer=ajaxServer;
                  i = myForm.aElements.length;
      myForm.aElements[i] = new G_Text(myForm, myForm.element.elements['form[USR_NAME]'],'USR_NAME');
      myForm.aElements[i].setAttributes({"label":"Nombre:","group":"2","mode":"edit","size":"35","validate":"4","mask":"","maxLength":"40","defaultValue":"","required":false,"dependentFields":"","linkField":"","strTo":"","readOnly":false,"sqlOption":[],"formula":"","function":"","options":[]});
                                            }
