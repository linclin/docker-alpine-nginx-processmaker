<?php
 $ERROR_TEXT = "400 Bad Request    ";
 $ERROR_DESCRIPTION = "Your browser (or proxy) sent a request
      that this server could not understand.<br />
      <br />
  ";
  
 include ( "header.php");
?>